package com.agynamix.guardian.wb.visual.figure;

import java.net.URL;

import org.eclipse.core.runtime.Platform;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.Panel;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;

import com.agynamix.guardian.wb.visual.VisualPlugin;


public class TransparentPanel extends Panel {

  static Image backgroundImage = null;
  
  boolean transparent = true;
  
  public boolean isTransparent()
  {
    return transparent;
  }

  public void setTransparent(boolean transparent)
  {
    this.transparent = transparent;
  }

  @Override
  protected void paintFigure(Graphics graphics)
  {
    if (isTransparent())
    {
      Image img = getBackgroundImage();
      if (img != null)
      {
        graphics.drawImage(img, 0, 0);
      } else {
        super.paintFigure(graphics);
      }
    } else {
      super.paintFigure(graphics);      
    }
  }

  protected static Image getBackgroundImage()
  {
    if (backgroundImage == null)
    {
      URL imageURL = Platform.getBundle(VisualPlugin.PLUGIN_ID).getEntry("/icons/transparent.gif"); //$NON-NLS-1$
      ImageDescriptor desc = ImageDescriptor.createFromURL(imageURL);
      backgroundImage = desc.createImage();
    }
    return backgroundImage;
  }
  
}
