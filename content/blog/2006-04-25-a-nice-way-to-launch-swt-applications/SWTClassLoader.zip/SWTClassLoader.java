class SWTClassLoader extends URLClassLoader {

  private final File workDir;
  private final Set loadedLibs = new HashSet();

  public SWTClassLoader(URL[] urls, File workDir) {
    super(urls);
    this.workDir = workDir;
  }

  protected String findLibrary(String libname) {
    String filename = System.mapLibraryName(libname);
    URL url = getResource(filename);
    if (url == null)
      return null;

    File file = new File(workDir, filename);
    if (!loadedLibs.contains(file))
      try {
        InputStream in = url.openStream();
        FileOutputStream out = new FileOutputStream(file);
        byte[] buf = new byte[4096];
        int c;
        while ((c = in.read(buf)) != -1)
          out.write(buf, 0, c);

        out.close();
        loadedLibs.add(file);
        in.close();
      } catch (IOException e) {
        return null;
      } finally {
        file.deleteOnExit();
      }

    return file.getAbsolutePath();
  }
}
