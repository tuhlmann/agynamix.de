#! /usr/bin/perl
#
# Asterisk Open-Exchange Dial Glue
# Based on TACI by Tony Wasson wasson@azxws.com
# 
# Author: Torsten Uhlmann (tuhlmann@agynamix.de)
# Version: 0.1
#
# This software is released under terms of the GNU General Public License (GPL)
#
# (c) 2006 AGYNAMIX (www.agynamix.de)


use lib '/usr/lib/cgi-bin';
use CGI;
use CGI qw(-no_xhtml);
use CGI::Carp qw(fatalsToBrowser);
use subs qw(exit);
use Net::Telnet ();
use Net::LDAP;

# use strict; # ToDo!

use OXtensions::OXSession qw(ox_getAuth ox_checkUser ox_getSessions ox_getErrorString);

# Where is your Asterisk server?
$asteriskServer = 'localhost';

# Insert the Username and Secret used for the Asterisk Manager
# Those must be present in Asterisk's manager.conf'
$mgrUSERNAME='axdial';
$mgrSECRET='axdial';

# For SMS
$motx_channel="CAPI/ISDN1/0193010";
$motx_callerid="03721273447";
$motx_retries=2;

# Which is the context where outbound calls should
# be placed at? (Your Asterisk admin should know)
$outboundContext='outbound-allroutes';

# Type of your phone extension (SIP/ZAP/CAPI/...)
# At the moment only tested with SIP
$globalPhonetype = 'SIP';

# Where is your LDAP server
# LDAP must be anonymous browseable
$ldapServer     = 'localhost';

# The Search base for your LDAP
# Please change the last 2 entries (dc=agynamix,dc=de)
$ldapSearchBase = 'ou=Users,ou=OxObjects,dc=agynamix,dc=de';

# Here we collect all user data
%userAccount;

# During the run we collect all messages and present them at the end
@messageArray = ();

%states = ('Default'     => \&buildForm,
           'Send SMS'    => \&sendSMS,
           'Call Number' => \&callNumber);

# Overall status of the operation
# If $statusOK switches to false we need to abort and
# present the error messages, if true we can close the
# small popup at the end
$statusOK = 1;

$| = 1; # do not buffer stdout

my $cgi = new CGI;

# Start the HTML
print $cgi->header(-charset=>'utf-8');
print $cgi->start_html(-title => 'Asterisk WebGlue', -style=>'/cfintranet/css/stylesheet.css',
                       -class=>'pager' );

my $sessionID = $cgi->param('session_id');
my $toCall    = $cgi->param('to_call');

$page      = $cgi->param('.State') || "Default";

if ($toCall eq "") {
   @messageArray = (@messageArray, "<p>No number to call!</p>");
   $statusOK = 0;
}

if ($statusOK) {
   if (($userID = getUserFromSession($sessionID)) eq "") {
      $statusOK = 0;
      @messageArray = (@messageArrayprint, "<p><bf>Could not authenticate user $userID! No active session.</bf></p>");
   } else {
      $userAccount{ 'uid' } = $userID;
      $toCall =~ s/([^A-Z0-9a-z\/@\.])//g;
      $userAccount{'toCall'}        = $toCall;
      $userAccount{'phonetype'}     = $globalPhonetype;

      if (!getUserAccountInfo()) {
         $statusOK = 0;
      } else {
         if ($states{$page}) {
            if (!($states{$page}->())) {
               $statusOK = 0;
            }           
         } else {
            no_such_page();
         }
      }
   }
}

if (!$statusOK) {
   print("<p><h4>Errors while trying to call $userAccount{'toCall'}:</h4></p>\n");
   foreach my $item (@messageArray) {
      print("$item\n");
   }
   print("<p><center><A HREF='' onclick='self.close()'>.:: Close ::.</A></center></p>");
}


print $cgi->end_html();

########### Subroutines ###################################################################
#

# build up the main form
sub buildForm {
   print("<script language='JavaScript'>\n",
         "function checkLength( element, maxLength ){\n",
         "  var len = element.value.length\n",
         "  if (len > maxLength) {\n",
         "    element.value = element.value.substr(0,maxLength);\n",
         "    len = maxLength;\n",
         "  }\n",
         "  document.getElementById('charsLeft').innerHTML = maxLength - len;\n",
         "}\n",
         "function forceLength( elemName, maxLength ){\n",
         "  var element = document.getElementsByName(elemName)[0];\n",
         "  document.getElementById('charsLeft').innerHTML = maxLength;\n",
         "  element.focus();\n",
         "}\n",
         "</script>\n");
   
   print($cgi->start_form());
   print($cgi->hidden(-name=>'session_id', -default=>$cgi->param('session_id')));
   
   my $toCall = $cgi->param('to_call');
   
   print("<table bgcolor=\"#000000\" align=\"center\" height=\"250\" width=\"480\" cellspacing=\"0\" cellpadding=\"1\">\n",
         " <tr valign=\"top\">\n",
         "  <td>\n",
         "   <table height=\"100%\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n",
         "    <tr valign=\"top\">\n",
         "     <td>\n",
         "      <table bgcolor=\"#F4EFB2\" cellspacing=\"0\" cellpadding=\"0\">\n",
         "       <tr>\n",
         "        <td background=\"/cfintranet/images/bg_top.gif\" align=\"right\" height=\"76\">\n",
         "         <img src=\"/cfintranet/images/sl_top_logo.png\" width=\"140\" height=\"76\" border=\"0\" alt=\"\"></td>\n",
         "       </tr>\n",
         "       <tr>\n",
         "        <td colspan=\"2\" width=\"450\">\n",
         "         <table class=\"pager\" width=\"480\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n",
         "          <tr>\n",
         "           <td align=\"left\">\n",
         "            <img src=\"/cfintranet/images/blank.gif\" width=\"20\" height=\"1\" alt=\"\">\n",
         "            Number\n",
         "          </td>\n",
         "         </tr>\n",
         "         <tr>\n",
         "        <td class=\"pager\" align=\"left\">\n",
         "         <img src=\"/cfintranet/images/blank.gif\" width=\"20\" height=\"1\" alt=\"\">\n",
         "         <input style=\"font-size:14px; font-family: verdana; border: 2 solid #FAA017; background:#FAFADC\" ",
         "           type=\"Text\" name=\"to_call\" value=\"$toCall\" size=\"\" maxlength=\"\">\n",
         "        </td>\n",
         "       </tr>\n",
         "       <tr>\n",
         "        <td>\n",
         "         <img src=\"/cfintranet/images/blank.gif\" width=\"5\" height=\"1\" >\n",
         "        </td>\n",
         "       </tr>\n",
         "       <tr>\n",
         "        <td valign=\"top\" align=\"left\">\n",
         "         <img src=\"/cfintranet/images/blank.gif\" width=\"20\" height=\"1\" >\n",
         "         SMS Text<img src=\"/cfintranet/images/blank.gif\" width=\"170\" height=\"1\">\n",
         "         <span id='charsLeft'>160</span> Chars left !\n",
         "       </td>\n",
         "     </tr>\n",
         "     <tr>\n",
         "      <td valign=\"top\" align=\"left\">\n",
         "       <img src=\"/cfintranet/images/blank.gif\" width=\"20\" height=\"1\" >\n",
         "       <textarea style=\"font-size:14px; font-family: verdana; border: 2 solid #FAA017; background:#FAFADC\" cols=\"55\" rows=\"7\" name=\"sms_text\" ",
         "       onkeyup=\"checkLength( this, 160 );\" onchange=\"checkLength( this, 160 );\" onmouseout=\"checkLength( this, 160 );\" ></textarea> \n",
         "      </td>\n",
         "     </tr>\n",
         "     <tr>\n",
         "      <td align=\"left\">\n",
         "       <img src=\"/cfintranet/images/blank.gif\" height=\"10\">\n",
         "      </td>\n",
         "     </tr>\n",
         "     <tr>\n",
         "      <td>\n",
         "       <img src=\"/cfintranet/images/blank.gif\" width=\"20\" height=\"1\">\n",
         "       <input style=\"font-size:14px; font-family: verdana; border: 2 solid #FAA017; background:#FAFADC\" type=\"Submit\" name=\".State\" value=\"Send SMS\">&nbsp;&nbsp;\n",
         "       <input style=\"font-size:14px; font-family: verdana; border: 2 solid #FAA017; background:#FAFADC\" type=\"Submit\" name=\".State\" value=\"Call Number\">&nbsp;&nbsp;\n",
         "       <input style=\"font-size:14px; font-family: verdana; border: 2 solid #FAA017; background:#FAFADC\" value=\"Clear\" type=\"reset\" onclick=\"forceLength('sms_text',160);\">&nbsp;&nbsp;\n",
         "       <input style=\"font-size:14px; font-family: verdana; border: 2 solid #FAA017; background:#FAFADC\" type=\"button\" name=\".State\" value=\"Cancel\" onclick=\"self.close()\"><br><br>\n",
         "      </td>\n",
         "     </tr>\n",
         "    </table></td></tr></table></td></tr></table></td></tr></table>\n");

    print($cgi->end_form());

#   print($cgi->p($cgi->center($cgi->h4("Number: $userAccount{'toCall'}\n"))));         
#   print($cgi->start_form());
#   print($cgi->hidden(-name=>'session_id', -default=>$cgi->param('session_id')));
#   print($cgi->hidden(-name=>'to_call', -default=>$cgi->param('to_call')));
#   print($cgi->p("SMS Text:"));
#   print("\n");
#   print($cgi->p($cgi->textarea(-name=>'sms_text', -rows=>5, -columns=>30,
#         -onkeyup    => 'checkLength( this, 160 );',
#         -onchange   => 'checkLength( this, 160 );',
#         -onmouseout => 'checkLength( this, 160 );'),
#         "<br />",
#         "<span class='small'><span id='charsLeft'>160</span> Chars left.</span>"));
#   print("\n");
#   print($cgi->p($cgi->submit(-name=>".State", -value=>"Send SMS"),
#                 $cgi->submit(-name=>".State", -value=>"Call Number"),
#                 $cgi->button(-name=>".State", -value=>"Cancel", -onClick=>"self.close()")));
#   print($cgi->end_form());

}

sub callNumber {
   my $rc = 0;
   if (($rc = originateCall()))
   {
      print("<script>self.close()</script>\n");      
   }
   return $rc;
}

# Send an SMS via Asterisk's smsq'
sub sendSMS {
   my $smsText = $cgi->param('sms_text');
   if ($smsText eq "") {
     @messageArray = (@messageArray, "<p>SMS Text is empty!</p>");
     return 0;
   }
   my $callStr = "/usr/bin/smsq --motx-channel=\"$motx_channel\" --motx-callerid=\"$motx_callerid\" --motx-retries=\"$motx_retries\" --da=\"$userAccount{'toCall'}\" --ud=\"$smsText\"";
   if (my $rc = system($callStr)) {
      @messageArray = (@messageArray, "<p>Could not send SMS to $userAccount{'toCall'}. RC=$rc</p>\n");
      @messageArray = (@messageArray, "<p>Command line: $callStr</p>\n");
      return 0;
   } else {
#      print("<p>Command line: $callStr</p>\n");
      print("<script>self.close()</script>\n");      
   }
   return 1;
}

sub no_such_page {
     @messageArray = (@messageArray, "<p>Script error.</p>");
     return 0;
}

# get the uid from the session, prevent nasty misuse this way
sub getUserFromSession {
  my $sessionID = @_[0];

  if ($sessionID eq "") {
     @messageArray = (@messageArray, "<p>No Session ID found. Please call the script with a session id (session_id=)</p>");
     return "";
  }

  my $sessionData = ox_getAuth($sessionID);

  return $sessionData->{'uid'};
}

# Call the Asterisk Manager and originate a call
sub originateCall {

  $tn = new Net::Telnet (Port => 5038,
                         Prompt => '/.*[\$%#>] $/',
                         Output_record_separator => '',
                         Errmode    => 'return'
                        );
  $tn->open("$asteriskServer");
  $tn->waitfor('/0\n$/');

  $tn->print("Action: Login\n");
  $tn->print("Username: $mgrUSERNAME\n");
  $tn->print("Secret: $mgrSECRET\n\n");

  if (!($tn->waitfor('/Authentication accept*/'))) {
     @messageArray = (@messageArray, "<p>Asterisk Manager Interface login failed, verify username and password: $tn->lastline</p>");
     return 0;
  }

  print("<p>Calling <em>$userAccount{'toCall'}</em>...</p>");

  $tn->print("Action: originate\n");
  $tn->print("Exten: $userAccount{'toCall'}\n");
  $tn->print("Context: $outboundContext\n");
  $tn->print("Channel: $userAccount{'phonetype'}/$userAccount{'userExtension'}\n");
  $tn->print("Priority: 1\n");
  $tn->print("WaitTime: 15\n");
  $tn->print("Timeout: 5000\n");
  $tn->print("Callerid: Calling $userAccount{'toCall'}\n\n");

  if (!($tn->waitfor('/Event: Newchannel.*/'))) {
     @messageArray = (@messageArray, "<p>Unable to determine call status: $tn->lastline</p>");
     return 0;
  }
  
  $tn->print("Action: Logoff\n\n");

}

# Ask the LDAP for the Pager number of the user
# The Pager number must contain the user's extension
sub getUserAccountInfo {
  my $ldap = Net::LDAP->new($ldapServer, port => 389, timeout => 15);
  if ($ldap) {
    my $mesg = $ldap->bind();

    $mesg = $ldap->search( filter=>"(uid=$userAccount{ 'uid' })", 
                           base=>"$ldapSearchBase",
                           attrs => ['pager']);

    if ($mesg->count != 1) {
      @messageArray = (@messageArray, "<p><bf>LDAP search returned wrong result: $mesg->count. Aborting.<bf></p>");
      return 0;
    }
    my $entry = $mesg->entry(0);
    my $s = $entry->get_value("pager");
    $ldap->unbind();
    if ($s eq "") {
       @messageArray = (@messageArray, "<p>User $userAccount{ 'uid' } has no Extension number defined in his 'Pager' field!</p>");
       return 0;
    }
    $userAccount{'userExtension'} = $s;
    return 1;
  } else {
    @messageArray = (@messageArray, "<p><bf>Could not connect to LDAP!\n");
    return 0;
  }
  
}
